# Asteria PMS register pack — v2

Nine registers for the revamped PMS agent. Generated, deterministic, and
modelled shape-for-shape on the six real `.xlsx` registers supplied as the
reference.

- **Dataset:** `registers/` — nine workbooks + `CHECKSUMS.sha256`
- **Answer key:** `ground-truth/` — **not part of the dataset**, evaluation only
- **Generator:** `tools/generators/pms-registers/`
- **As-at date:** 2026-09-13. Rolling 90 days = 2026-06-15 → 2026-09-13.
  Trailing 12 months = 2025-09-13 → 2026-09-13. Register rows span
  2025-01-01 → 2026-09-12 (20.4 months); the fleet starts installing 2024-09-15.

Do not hand `ground-truth/` to anything being evaluated. It contains the true
entity map, the true event labels, and the planted-story markers.

---

## 1. The nine registers

### Source registers — six, same shape as the real files

| # | File | Sheets | Rows | Cols |
|---|---|---|---:|---:|
| 1 | `PM-Customer-Organisations-and-Hubs-Record.xlsx` | Organisations | 16 | 18 |
| | | PulseOne Hub Inventory | 250 | 15 |
| | | PulsePatch Stock Allocation | 275 | 10 |
| 2 | `PM-Incident-and-Outage-Log.xlsx` | Incidents & Outages | 737 | 20 |
| 3 | `Product-Return-and-Replacement-Register.xlsx` | Returns & Replacements | 308 | 20 |
| 4 | `PM-Data-Check-and-Troubleshooting-Log.xlsx` | Data Check & Troubleshooting | 712 | 15 |
| 5 | `PM-Client-Communications-Log.xlsx` | Client Communications | 566 | 15 |
| 6 | `PMS-Plan-and-Report-Register.xlsx` | PMS Documents | 24 | 10 |
| | | Indicators & Thresholds | 7 | 10 |
| | | PMS Review Meetings | 22 | 9 |

Column names and column order are the real files'. Three columns are added, all
appended after `Notes` so the original order is untouched:

- Incident log: **`Event Code`** (the indicator internal code — blank or wrong
  on human-entered rows, always correct on telemetry rows) and **`Source`**
  (`Telemetry` / `Dashboard alert` / `Ward staff` / `Email`).
- RMA register: **`Linked Signal`**.

### System-maintained register exports — three, new

| # | File | Rows | Cols |
|---|---|---:|---:|
| 7 | `Signal-Register.xlsx` | 18 | 22 |
| 8 | `Product-NC-Register.xlsx` | 5 | 18 |
| 9 | `Agent-Action-Log.xlsx` | 0 | 10 |

**These are history only.** See §5.

These workbooks are deterministic demo fixtures and controlled exports. In the
application, the live records, approvals, provenance and action history are
stored in Postgres; the workflow does not edit these files as its database.

---

## 2. The indicator rule set — seven indicators, two threshold kinds

The `Indicators & Thresholds` sheet carries **seven** rows, not six. IND-07
(`DISPLAY`, baseline 0.8, threshold 3.0x, review function Service) is in the
real file and is carried through here.

Six thresholds are ratios. **IND-06 `SKIN` is `Any increase - clinical
review`** — there is no multiplier, so any rise of the rolling 90-day rate over
the trailing 12-month rate goes to clinical. Anything consuming this sheet
needs a threshold *kind*, not a bare number.

**IND-06 has no telemetry path.** A patch cannot detect a rash. Every `SKIN`
event in the dataset arrives through a person — a ward check, a client email,
or a technician's finding on a returned sample. Verified: 0 `SKIN` rows carry
`Source = Telemetry`.

---

## 3. Denominators — the arithmetic

Both denominators are computed from sheet 1, never invented.

### Unit-months in service

The inventory sheet carries **six** `Unit Status` values, and two of them mean
the same thing. Which statuses accrue:

| Status | Count | Accrues? |
|---|---:|---|
| `In service` | 202 | yes |
| `Installed` | 19 | yes — same state, different word. Treating these as distinct is a denominator bug |
| `At depot (RMA)` | 6 | yes, up to the day it went to the depot |
| `Decommissioned` | 8 | yes, up to its decommission date |
| `Spare` | 9 | **no** — sitting in a cupboard |
| `Shipped - not installed` | 6 | **no** — not on a patient yet |

The sheet has **no decommission-date and no depot-date column**, because the
real one has neither. Both are inferred in the world model and live in
`ground-truth/hubs.csv` (`decommission_date`, `depot_from`, `accrual_end`) so
the denominator can be recomputed exactly.

HW revision has **three** values, carried as a real cohort axis: H1 125,
H2 89, H2.1 36.

Working backwards from the baselines to pick the scale:

```
250 hubs, 82% installed before 2025-09-13 so they accrue the whole window
  unit-months, trailing 12 months   2504.2   (= 25.04 blocks of 100)
  unit-months, rolling 90 days       650.3   (=  6.50 blocks of 100)
  unit-months, full 20.4-month span 3609.0

IND-01 @ 1.3 per 100 um  ->  1.3 x 25.04 =  33 events/yr   (observed 34)
IND-02 @ 0.9             ->  0.9 x 25.04 =  23             (observed 34, +near-miss)
IND-03 @ 0.6             ->  0.6 x 25.04 =  15             (observed 27, +BATT story)
IND-04 @ 1.1             ->  1.1 x 25.04 =  28             (observed 42, +ALERT story)
IND-07 @ 0.8             ->  0.8 x 25.04 =  20             (observed 20)
```

### Patches distributed

```
  patches, trailing 12 months   110,125   (= 110.1 blocks of 1,000)
  patches, rolling 90 days       41,938
  patches, full span            156,794

IND-05 @ 0.4 per 1,000   ->  0.4 x 110.1 = 44 events/yr    (observed 60, +lot story)
IND-06 @ 0.12            ->  0.12 x 110.1 = 13             (observed 12)
```

**Assumption recorded:** 250 hubs each monitoring one patient with a ≤72-hour
patch consume on the order of 30,000 patches a year at full utilisation. This
pack ships ~110,000 a year, about 3.7x that. Allocation is not consumption:
wards hold stock, and one of the sixteen customers is a distributor taking
stock for onward sale it never reports back (`Distributor onward allocation not
reported` appears in the Notes column). The real reference file runs at ~134
patches per hub per year; this pack runs at ~440. The reason for going above
the physical floor is statistical power — at true consumption, IND-06's 0.12
baseline produces about 3 events a year, and a 90-day comparison on 0.8 expected
events is meaningless. This is the one place where demo usability was chosen
over physical realism, and it is the number to change first if that trade is
wrong.

---

## 4. Computed indicator rates vs baselines

All seven recomputed **from the emitted workbooks** — messy serials resolved,
blank cells handled, denominators rebuilt from the inventory and allocation
sheets. Run `python3 tools/generators/pms-registers/generate.py`; the full
output is in `ground-truth/verification.txt`.

| Indicator | Code | Baseline | 12mo as at plan approval | Trailing 12mo (now) | Rolling 90d | 90d ÷ baseline | Threshold | Breach |
|---|---|---:|---:|---:|---:|---:|---|---|
| IND-01 | CONN-LINK-LOSS | 1.30 | **1.35** | 1.36 | 1.08 | 0.83x | 2.0x | no |
| IND-02 | HUB-OFFLINE | 0.90 | **1.00** | 1.36 | 2.61 | 2.90x | 2.5x | **yes** |
| IND-03 | BATT | 0.60 | **0.55** | 1.08 | 1.08 | 1.79x | 2.0x | no |
| IND-04 | ALERT-FALSE | 1.10 | **1.10** | 1.68 | 3.08 | 2.80x | 2.0x | **yes** |
| IND-05 | ADHESIVE | 0.40 | **0.39** | 0.54 | 0.55 | 1.37x | 2.0x | no |
| IND-06 | SKIN | 0.12 | **0.12** | 0.11 | 0.07 | 0.60x | any increase | no |
| IND-07 | DISPLAY | 0.80 | **0.80** | 0.80 | 0.92 | 1.15x | 3.0x | no |

**Read the bold column.** The baselines live in PMS-PLAN-001 v3.0, approved
2026-02-12. The honest test of "do the rates land near the baselines" is the
12 months *ending on that approval date* — which is the data the baseline was
computed from. All seven land within 11% (worst: IND-03 at −8%, IND-02 at +11%).

The trailing-12-month column read from today is deliberately higher for
IND-02/03/04/05, because the planted stories are inside that window. That is
what a real trailing window does when something is going wrong now. It is not
a generation error, and the baselines were not adjusted to hide it.

Statistical power, stated plainly: the 90-day numerators are 3–23 events. That
is what a 250-unit fleet at these baselines produces, and it is the binding
constraint on this dataset (see §8).

---

## 5. Where the line is drawn on the system-maintained registers

**Rule: no row in `Signal-Register.xlsx` has a `Window end` after 2026-05-31.**

The live rolling window starts 2026-06-15. Every planted story sits inside it
and has **no** pre-written signal, **no** NC and **no** action-log entry. The
the Signal and Product NC exports provide a believable two-year back-catalogue,
while the Agent Action Log starts empty for the live demo: 18 closed or
monitoring signals, 5 closed NCs and 0 logged actions.

What *is* pre-generated:

- 18 signals: 12 closed no-action, 4 promoted to NCs, 2 on monitoring. Their
  `Linked events` are real `INC-*` IDs from the window and cohort each signal
  covers. `Agent rationale` is what the agent wrote when it raised the signal
  (what breached, by how much, over what denominator, what it thinks);
  `Outcome rationale` is what the human wrote when closing it. They differ.
- 5 NCs, all closed. `Evidence links` resolve to real rows in the RMA,
  troubleshooting, comms and incident registers.
- An empty Agent Action Log template. The live workflow appends every action,
  including its autonomy level and subsequent human verdict.

Two of the historical signals are deliberately adjacent to the live stories and
stop just short of them — `SIG-2026-0013` (BATT on H1, left on *monitoring*,
asking service to record measured capacity) and `SIG-2026-0018` (ALERT-FALSE
fleet-wide, closed no-action with a minuted note that three of the reporting
sites are on the newest software and it is worth a look next cycle). They are
precedent for the live agent to find, not the answer.

---

## 6. The messiness model

Rates were measured off the six real registers first, then applied. Measured vs
produced:

| Dimension | Real files | This pack |
|---|---|---|
| Incident: Serial Number blank | 16.7% | 11.4% |
| Incident: BedID blank | 16.7% | 12.8% |
| Incident: SW Version at Time blank | 34.4% | 34.7% |
| Incident: Assigned To blank | 22.9% | 21.3% |
| Incident: Notes blank | 64.6% | 63.5% |
| Reported Date: real date cell | 88.5% | 89.0% |
| Reported Date: `dd/mm/yyyy` text | 5.2% | 5.4% |
| Reported Date: `yyyy-mm-dd` text | 4.2% | 3.5% |
| Reported Date: `dd Mon yyyy` text | 2.1% | 2.0% |
| Troubleshooting: Patch Lot blank | 50.7% | ~51% |
| RMA: SW Version blank | 48.3% | ~48% |
| RMA: Replacement Serial blank | 84.5% | ~85% |
| Comms: Contact Role blank | 46.1% | ~46% |

**Serial number shapes** (1,757 cells across the incident, RMA and
troubleshooting registers):

| Shape | Example | Share |
|---|---|---:|
| canonical | `PO-P1-004216` | 59.3% |
| blank | | 15.4% |
| `SN nnnn` | `SN 4216` | 6.5% |
| six digits | `004216` | 5.8% |
| four digits | `4216` | 4.7% |
| `P1100-nnnn` | `P1100-4216` | 4.0% |
| lowercase | `po-p1-004216` | 2.6% |
| trailing whitespace | `PO-P1-004216 ` | 1.7% |

**Organisation names**: 5 variants per customer (canonical / short / abbrev /
legal / alt), sampled 42/22/15/11/10%. 71 distinct organisation strings appear
in the incident log alone for 16 customers. Every one resolves to exactly one
customer — verified, 0 unresolvable and 0 ambiguous.
Examples: `Royal North Hospital` / `Royal North` / `RNH` / `Royal Nth Hospital`;
`St Auburn Private Hospital` / `St. Auburn` / `SAPH` / `Auburn Private` /
`St Auburn Private Hospital Ltd`.

**Ward names**: canonical 78%, `WARD 3B` 10%, bare `3B` 8%, `Ward 3b` 4%. One
customer's ward IDs use a space rather than a hyphen throughout (`WARD 14`,
`WARD 12`), as in the real file.

**Lot codes**: canonical 78%, no prefix `2604-B19` 8.5%, lowercase 3.5%, stem
only `2604` 4.5%, `L-2604-B19 (from pouch photo)` 5.5%.

**Event Code** on the 307 indicator-carrying incident rows:

| | Share |
|---|---:|
| Telemetry-sourced, correct | 32.2% |
| Human-entered, correct | 31.9% |
| Human-entered, blank | 27.4% |
| Human-entered, **wrong** | 8.5% |

Telemetry rows are never wrong (verified). Wrong human codes are plausible
wrong codes — `HUB-OFFLINE` on a link-loss row, invented codes like `LINK-LOSS`,
`FALSE-ALERT`, `BATTERY`.

**Other deliberate mess kept from the real files**: `Last Online` in the
incident log is a snapshot copied from the inventory, not the time of the
incident — the column looks event-related and is not; `SW Version Observed On`
is sometimes a year in the future because somebody typed the wrong year;
`Ward-wide outage` and `Network dropout - dashboard blank` appear both as
`HUB-OFFLINE` renderings and as non-indicator rows, so the description-to-code
map is genuinely imperfect; 430 incident rows (58%) carry no indicator at all.

---

## 7. The planted stories

All four verified against the emitted workbooks. Full numbers in
`ground-truth/verification.txt`.

### S1 — ALERT-FALSE on SW 1.1.0 (the primary story)

- Fleet IND-04 over the rolling 90 days: **3.08 per 100 unit-months = 2.80x**
  the 1.10 baseline. Threshold is 2.0x. **Breach.**
- Slice by software version: **1.1.0 hubs run 14.28 (13.0x); everything else
  runs 1.09 (1.0x).** n=14 on a 98 unit-month denominator.
- Visible across exactly **three organisations** — CUST-0052 Cathedral Hill,
  CUST-0061 Riverbend, CUST-0070 Harbour City. 1.1.0 exists at six sites; those
  three hold 28 of the 36 units.
- **The discriminating slice**: inside those same three sites, 1.1.0 hubs run
  **18.32** and non-1.1.0 hubs run **1.35**. It is the software version, not
  the site.

**Why it is not visible from any single register:**

| Register alone | What it shows | What it cannot do |
|---|---|---|
| Incident log | ~20 false-alert rows in 90 days | No denominator at all, so no rate. Of the 15 story rows, **2 (13%)** carry a correct `SW Version at Time` — the rest are blank or stale. The 1.1.0 cohort cannot be recovered. |
| Hub Inventory | Which hubs run 1.1.0 | No events |
| Troubleshooting log | **11 checks** in the window naming `1.1.0 alert logic`, `Threshold set to default not ward profile`, `Alert thresholds defaulting on reboot` | Free text only, no rate, 26% of rows have no serial |
| RMA register | **5 returns raised in the window** finding `no hardware fault` / `Configuration reset to ward profile` (22 across the register) | Five returns is not a trend |
| Client comms | **18 emails** in the window about night-time false alerts | Subjective, no units, no rate |

The join — inventory ⋈ incident on HubID/serial, sliced by SW version, against
unit-months from the inventory — is the only thing that produces the finding.

### S2 — BATT on H1 units past 18 months (cohort-only, no fleet breach)

- Fleet IND-03 over 90 days: 1.08 = **1.79x**, under the 2.0x threshold. A
  fleet-level view sees nothing.
- H1 units installed more than 18 months ago: **1.74 = 2.90x**, n=4 on a
  230 unit-month denominator.
- Corroborated by **17 RMA rows** whose Technician Findings read exactly
  `Battery module replaced, capacity 61% of nominal`.
- Needs HW revision *and* install date from the inventory. Honest caveat: the
  in-window cohort numerator is 4 events. It is a weak-but-real cluster, which
  is the correct texture for a secondary thread — the RMA findings are the
  strong part of the evidence, not the rate.

### S3 — ADHESIVE on two patch lots (lot-only, no fleet breach)

- Fleet IND-05 over 90 days: 0.55 = **1.37x**, under threshold.
- Lots `L-2604-B19` + `L-2605-C34`: **0.93 = 2.31x**, n=6 over 6,480 patches of
  those lots shipped inside the window.
- Needs the Patch Lot Allocation sheet for the lot-level denominator. The lot
  codes in the troubleshooting log are messy (`2604-B19`, `l-2605-c34`,
  `L-2604-B19 (from pouch photo)`), so the slice needs normalisation first.

### S4 — the near-miss (correctly closed no-action)

- **10 HUB-OFFLINE rows at CUST-0073 (Ashfield Private) inside six days**,
  2026-08-17 → 2026-08-22.
- It **does breach**: fleet IND-02 over 90 days is 2.61 = **2.90x** against a
  2.5x threshold. The agent is right to raise it.
- **9 of the 10 rows** carry a note that explains it — `Hospital network
  maintenance window`, `Local bedside function unaffected`, `Planned network
  cutover - site notified us after the fact`, `Rebooted remotely, back online`.
- **17 client emails** say the same thing.
- The correct human outcome is *Closed – no action*, with a rationale. Precedent
  exists: `SIG-2025-0003` is the same story at a different site, closed the same
  way.

---

## 8. What does not hold

**Row counts are below the brief's "2500+ incident/outage rows".** The incident
log has 737 rows. This is a genuine conflict in the brief and it was resolved in
favour of the baselines, because requirement D says explicitly to fix the
generation rather than the baselines.

The arithmetic: at 250 hubs (the top of the brief's 180–250 range) the trailing
12 months contain 2,504 unit-months. The five PulseOne baselines sum to 4.7 per
100 unit-months, so the indicator events the baselines permit are
`4.7 × 25.04 ≈ 118 a year`, or ~200 over the 20-month span. Patch indicators add
~57 more. To make ~1,700 indicator rows consistent with these baselines would
need roughly **21,600 unit-months in the trailing 12 months — about 1,800
hubs**, seven times the permitted fleet. The two requirements cannot both hold.

What was done instead:

- The incident log carries 307 indicator rows and 430 non-indicator rows.
- The registers that are *not* indicator numerators were taken to the brief's
  volumes: 712 troubleshooting checks (2.8 per hub over 20 months), 566 client
  communications (~1.7 per customer per month), 308 RMAs.
- Patch volume was raised above physical consumption (§3) to buy what
  statistical power was available for IND-05/06.

**Consequence to be aware of:** the 90-day numerators are 3–23 events. A 2.0x
breach on IND-04 is 20 events against ~7 expected — comfortably outside Poisson
noise. A 2.0x breach on IND-06 would be 2 events against 1. IND-06 is not
statistically testable at this scale and never will be at a 0.12 baseline; its
"any increase" threshold is arguably an acknowledgement of exactly that.

If more volume is needed, the lever is `HUB_COUNT` in `config.py`. Raising it
scales the denominator and the event quotas together, so the rates stay on
baseline and the row counts rise proportionally. Going to 1,800 hubs would hit
the brief's row target and keep every rate — at the cost of no longer being a
16-customer company.

**Also worth knowing:**

- Two organisations in the reference file named real health bodies
  (`Waitemata District Hospital` / `Te Whatu Ora Waitemata`, and
  `NHS Grampian`). They were renamed to `Kaimanu District Hospital` and
  `Brackenmoor Royal Infirmary` / `Brackenmoor Health Board`, keeping the same
  shape of name sloppiness. Everything else in the world is fictional and
  unchanged from the reference.
- The `Product-NC-Register` narrative fields (root cause, CAPA rationale) are
  hand-written, not generated. Five NCs is too few for a generator to write
  convincingly.
- Signal `Event count` and `Denominator value` for the 18 historical signals are
  internally consistent with the stated rate but are not recomputed from the
  registers — they are what the agent recorded at the time, on a fleet that has
  since changed.

---

## 9. Ground truth

`ground-truth/` — **not the dataset**. For scoring only.

| File | What it is |
|---|---|
| `hubs.csv` | Every hub: true serial and its 4 messy renderings, customer, ward, HW, SW, install date, unit status, whether it accrues, decommission date, depot date, accrual end, and its unit-months for both windows |
| `organisation-variants.csv` | Every organisation string that appears anywhere → the one customer it means |
| `events.csv` | Every world event: true indicator code, timestamp, hub, lot, story marker, and which registers it surfaced in |
| `incident-links.csv` | `INC-*` → event, hub, true serial, true code, true SW/HW, story marker |
| `rma-links.csv`, `check-links.csv`, `comm-links.csv` | The same for the other three human registers |
| `patch-allocations.csv` | Clean lot allocation for denominator recomputation |
| `generation-report.json` | Row counts, denominators, all seven rates |
| `verification.txt` | The full verification run |

Entity-resolution scoring: join the agent's resolved entity against
`incident-links.csv` / `organisation-variants.csv` on the register row ID.

---

## 10. Regenerating

```sh
python3 tools/generators/pms-registers/generate.py
```

No arguments. Needs `openpyxl` (3.1.5 used; Python 3.9+). Writes
`registers/`, `ground-truth/`, and `CHECKSUMS.sha256`, and prints the
verification run.

Deterministic: one seed (`SEED` in `config.py`), no clock reads, RNG built only
on `random()` so stdlib helper changes cannot shift it, and OOXML packages
normalised (fixed zip timestamps, fixed `docProps`). Two runs are
byte-identical — confirmed.

```sh
cd mock-company-v2/registers && shasum -a 256 -c CHECKSUMS.sha256
```

Knobs worth knowing, all in `config.py`: `HUB_COUNT`, `INCIDENT_NONINDICATOR_ROWS`,
`TROUBLESHOOTING_ROWS`, `CLIENT_COMMS_ROWS`, `RMA_ROWS`, the `STORY_*` block
(story strength and placement), `BLANKS` (per-column blank rates), and the
`*_VARIANT_MIX` tuples (identifier rendering).
