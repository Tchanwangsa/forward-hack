# Asteria Medical Systems — source data pack

**Dataset version 0.1.0 · as at 2026-09-10 · frozen 2026-09-13 · 1,690 files**

This directory is a snapshot of eleven business systems belonging to one fictional
medical device company, exported the way each system actually exports. It exists so
that software which has to read a real company's systems can be built and tested
against something that behaves like one.

It is not a tidy dataset. Every system here has its own identifiers, its own date
format, its own idea of what a customer is called, and its own export day. None of
them were designed to be joined to each other, because the systems of a real
80-person company are not.

Read `source-manifest.yaml` next. It describes every source: what it is for, who owns
it, when it was exported, what format and encoding it uses, what timezone convention
it follows, and what its export does not contain.

---

## What the company is

Asteria Medical Systems Pty Ltd is a fictional medical device manufacturer based in
Melbourne, Australia. Roughly 80 people. It makes two products:

- **PulseOne (`P1-100`)** — a reusable bedside patient monitoring receiver, sold to
  hospitals as a capital item. Three hardware revisions, six software versions.
- **PulsePatch (`PP-72`)** — a single-use adhesive sensor patch, sold by the box as a
  consumable.

It sells in Australia (its main market, since before this dataset begins), Ireland and
the Netherlands through direct supply, and in the United States since February 2026
through a single importer selling to one hospital network in Illinois. It operates a
quality management system to ISO 13485 and holds regulatory obligations in each of
those markets.

Everything in this pack is invented. No real company, hospital, clinician, patient,
device, incident or event appears anywhere in it. Regulatory citations — ISO clause
numbers, MDR articles, 21 CFR parts — are real and are the only real-world facts in
the tree.

---

## The systems, and who owns each

| Directory | System | Owned by | Exported | Formats |
|---|---|---|---|---|
| `crm/` | Sales CRM | Commercial | 2026-09-02 | CSV |
| `support/` | Hosted ticketing platform | Customer Support | 2026-09-07 | JSONL, JSON, images |
| `email/` | Five shared mailboxes | IT / each function | 2026-09-09 | `.eml` |
| `erp/` | ERP — orders, dispatch, production, purchasing | Operations and Supply | 2026-09-07 | CSV |
| `installed-base/` | Device register | Operations / Service | 2026-09-09 | CSV |
| `service/` | Service and RMA system | Operations / Service | 2026-09-03 | CSV, images |
| `qms/` | QMS repository and registers | Quality | 2026-09-08 | PDF, DOCX, XLSX |
| `meetings/` | Calendar, minutes, action register | Quality / IT | 2026-09-04 | ICS, DOCX, PDF, XLSX, TXT |
| `pms/` | Post-market surveillance working files | Quality | 2026-09-04 | CSV, XLSX, DOCX, PDF |
| `slack/` | Slack workspace, six public channels | IT / each team | 2026-09-09 | JSON |
| `drive/` | Shared and personal drive folders | individuals | 2026-09-08 | DOCX, XLSX, JSONL |

**The export dates differ on purpose.** Each system was exported on its own day,
between 2 and 9 September 2026, against a dataset as-at of 10 September 2026. The
systems therefore disagree about what the most recent record is. Do not reconcile
that away; it is the condition any real integration works in.

### Date range

Operating history runs **March 2025 to August 2026**, with the trailing days of each
system running to its own export date. There is earlier material where a real company
would have it: manufacturing and first shipments from September 2024, controlled
documents approved as far back as 2018, drive folders created in 2022. Some dates are
deliberately in the future — a periodic document review due in 2029, a consumable lot
expiry in 2027, a meeting already in the calendar. Those are forward-looking fields,
not records of things that happened.

---

## How to load each format

Nothing here needs a special tool. It does need you to stop assuming.

**CSV** (`crm/`, `erp/`, `installed-base/`, `service/`, `pms/monthly-exports/`)
Four different dialects. CRM quotes every field and writes dates `3 Mar 2025`; ERP
quotes minimally, uses CRLF, and writes `03/03/2025` with multi-line address blocks
inside quoted fields; the installed base is snake_case with ISO dates and LF; service
is CRLF with `DD/MM/YYYY`. Read with a real CSV parser in `newline=''` mode — a
line-splitter will break on the embedded newlines. Do not assume a column named
`date` shares a format with another file's column named `date`.

**JSON Lines** (`support/`, `drive/`) One object per line, UTF-8, LF. Timestamps are
UTC with a trailing `Z`.

**JSON** (`slack/`, `support/tags.json`) The Slack tree is a standard workspace
export: `channels.json`, `users.json`, and one array per channel per day at
`<channel>/YYYY-MM-DD.json`. Message timestamps are Unix epoch seconds as strings;
the `ts` is also the message's identity within its channel. **The daily files are
bucketed by UTC date, not by local date** — a Melbourne working day spans two files,
and a thread root can sit in a different file from its replies.

**`.eml`** (`email/`) RFC 5322, CRLF, one file per message, MIME multipart where there
are attachments or an HTML part. Parse with a real MIME parser. Threads reconstruct
from `Message-ID`, `In-Reply-To` and `References` and from nothing else — there is no
conversation id. `Date` headers carry each sender's own UTC offset; sorting on the
local clock will reorder some threads.

**`.ics`** (`meetings/calendar.ics`) RFC 5545, CRLF, folded lines. Two `VTIMEZONE`
blocks. Recurring meetings are `RRULE` masters with `RECURRENCE-ID` overrides and
`EXDATE`s — you must expand them to get the occurrences, and a deleted occurrence
appears as an `EXDATE` in one case and as a cancelled override in another.

**DOCX / XLSX** OOXML packages. The DOCX records carry real tracked changes and real
reviewer comments: a naive text extraction will silently merge inserted and deleted
text and drop the comments. The XLSX workbooks carry live formulas, several sheets
per workbook, hidden rows, and merged cells. Read both the formula and the cached
value; they are not the same information.

**PDF** Approved and closed records. Most carry a real text layer (ASCII85 + Flate
content streams, so raw-byte grepping will find the document title and nothing else).
**Two controlled documents are scans with no text layer at all** and will yield zero
characters until they are OCRed. A pipeline that silently returns an empty string for
those is failing quietly.

**Images** (`support/attachments/`, `service/attachments/`, `slack/files/`) Photographs
taken on phones and screenshots. Some of them are the only place a value appears.

---

## What is deliberately messy

Every one of these is a property of how the systems and the people using them behave.
None of it is random corruption, and none of it should be "cleaned up" before the
thing you are building has to deal with it.

**Identity is not given to you.**
There is no shared customer key, account key or person key across these systems. Each
system invented its own. An organisation is written under its legal name in one system,
under a trading name in another, and under an abbreviation someone typed in a third.
The same person appears under two email addresses. Two people share a surname. A shared
mailbox sends on behalf of more than one person. A contact moves to a different site.
Resolving any of this requires inference from names, addresses, sites and behaviour —
which is the problem, not an obstacle to it.

**Device serial numbers are the one identifier that travels**, because they are printed
on the device and people read them off it. They are written several ways: formally in
service and dispatch records, as bare digits by nurses, zero-padded in one export, in
lower case in chat. At least one is transcribed wrongly somewhere, and both the correct
and the incorrect form are real units. A resolver that picks the plausible-looking one
will sometimes be wrong.

**Timestamps disagree.** Some systems record a true offset, some record naive local
time with no zone at all, one records UTC, one records Unix epoch floats, and one
records dates with no time. Three Australian daylight-saving transitions fall inside
the range. The same event reaches two systems with two different timestamps, and the
date a thing was received, the date it was logged and the date the record was created
are three different dates that do not always agree.

**Records are incomplete in ways that mean something.** A null and an absent field are
different: one form has a field its user left blank, another form does not have the
field at all. Registration of a device is voluntary and many units were never
registered. Software version observations are opportunistic and frequently months
stale. Categorisation is manual, so the same symptom carries different tags from
different people, and a large share falls into a catch-all.

**Registers lag repositories.** Hand-maintained spreadsheets are the index of record
for several document and record sets, and they are behind the folders they index — a
listed revision the repository has moved past, a row pointing at a file that is not
there, a title the document no longer uses, a status spelled six ways. Workbooks carry
live formulas, hidden rows and hard-coded assumptions typed next to the cells that use
them.

**Free text carries what the structured fields do not.** Symptom, finding, work done,
test result and disposition are five separate columns and they frequently disagree.
Some decisions exist only in a chat thread or a meeting transcript. A transcript, its
draft minutes and its approved minutes do not say the same thing.

**Duplicates, merges and soft deletes are still present.** Merged tickets remain as
stubs. A trashed drive file is still fully readable. An obsolete document sits in a
personal folder with nothing marking it obsolete.

### What that means if you are building an ingestion pipeline

- Parse per source, never once generically. Column names, date formats, line endings
  and encodings are per-system facts.
- Preserve the source's own surface form alongside anything you normalise. The
  inconsistency is evidence.
- Never join on a guess. The joins across these systems are inferences and should be
  produced with a confidence and a reason, not silently.
- Make missing data visible. If a document yields no text, a field is absent rather
  than null, or a register row has no file behind it, say so; do not pass an empty
  string downstream.
- Do not reconcile the export dates. Two systems disagreeing about the latest record
  is a fact about the exports, not an error to average away.

---

## What is not here

- **Nothing that tells you the answer.** Nothing in this directory says what the data
  means, what a reader should conclude from it, which records relate to which, or what
  any analysis should find. There are no evaluation labels and no cross-source mappings
  — not in the data, not in the manifest, not in this file.
- **No generation seed and no private simulation state.** The dataset is produced
  deterministically from a simulation that is held outside this directory. Neither the
  seed nor the simulated state is in this tree, deliberately: anything that let you read
  the simulation directly would remove the problem this pack exists to pose.
- **No personal data of real people**, and no real organisations, devices or incidents.
- **No pricing**, no payment data and no patient identifiers.
- **No direct messages or private channels** in the Slack export, no deleted items in
  the mail export, no field-level history in the CRM or the device register beyond the
  single history file each one keeps.
- **No database dumps, no API credentials, no live URLs.** Attachment and file URLs in
  the JSON exports point at systems that do not exist and will not resolve.

---

## Verifying this pack

```bash
# file integrity
cd mock-company && shasum -a 256 -c CHECKSUMS.sha256

# the full check suite (format, encoding, referential integrity, identifier
# isolation, date ordering, attachments) - run from the repository root
python3 tools/freeze/integrity.py --verbose
python3 tools/freeze/leak_scan.py --root mock-company
```

This tree is **immutable at 0.1.0**. Do not edit files in it. If something here is
wrong, it is wrong in the generator, and the fix is to regenerate and re-freeze at a
new version — otherwise a result measured against this pack cannot be compared with
any other.

### Known defects at 0.1.0

The integrity suite found five. Four were traced to their generator and fixed at
source, then re-rendered — patching a generated file by hand would make the pack
unreproducible, so nothing here was edited in place. One remains.

| Where | What | Status |
|---|---|---|
| `installed-base/version-observations.csv` | 23 rows of 3,786 carry an `observed_on` earlier than the unit's `manufactured` date — a software version seen on a device before it was built. | **Open.** The bad dates come from the simulated world, not from this renderer, so fixing it means regenerating the world and re-rendering all six sources. Deferred to 0.2.0 rather than destabilising a coherent 0.1.0 for 0.6% of one file. `tools/freeze/integrity.py` fails on it, loudly, by design. |
| `pms/monthly-exports/*.csv` (41 files) | Every line ended `CR CR LF`. | Fixed. The writer passed `newline="\r\n"` to `open()` *and* `lineterminator="\r\n"` to `csv.writer`, so Python translated the newline twice. `newline=""` is the csv module's documented requirement. |
| `meetings/action-register.xlsx` | One row dated after the dataset as-at. | Fixed. Action dates are now clamped to the tracker's own export cut-off — a row cannot exist in an extract taken before it. |
| `support/status-history.jsonl` | On three merged tickets the merge's closing transition sat mid-lifecycle, breaking the `previous_value` chain. | Fixed. The merge close is now timestamped after every natural transition, because it is the last thing that happens to a merged ticket. |
| `support/comments.jsonl` | An internal note predated its own ticket. | Fixed. A complaint can legitimately be opened before its ticket exists, but an agent cannot paste a note onto a ticket that does not exist yet, so the note is floored at the ticket's creation. |

None of these are the messiness described above. **That messiness is behaviour; these
are bugs** — which is the distinction the integrity suite exists to hold. A defect that
gets explained away as realism is a defect you will ship twice.
